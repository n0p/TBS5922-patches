#!/usr/bin/env python3
"""dvbs-blindscan - blind scan for DVB-S/S2 frontends without hardware
blindscan support (tested with TBS 5922 / TAS2101 + AV2012).

Because the TAS2101 has no DVBv5 blindscan API, this does it in two stages:

  1. AGC survey: sweep the IF band with the widest possible tuner bandwidth
     (max symbol rate) and record the demod AGC level.  Real carriers show up
     as pronounced dips/peaks against the noise floor.
  2. Lock hunt: around every AGC feature, try a list of symbol rates.  When
     the demod locks, ask it for the *measured* symbol rate (get_frontend),
     so the transponder is reported with its real SR.

Output: CSV with every lock plus a dvbv5 channel file with the found
transponders (ready for dvbv5-scan / dvbv5-zap).

Usage:
  dvbs-blindscan [--adapter N] [--quadrants VL,HL,VH,HH] [--step MHZ]
                 [--srs 45000,27500,8000,3000] [--out PREFIX] [--agc-only]
"""
import argparse
import os
import subprocess
import sys
import time

TUNE = "/usr/local/bin/dvbs-tune"

QUADRANTS = {
    "VL": ("V", "L", 9750),
    "HL": ("H", "L", 9750),
    "VH": ("V", "H", 10600),
    "HH": ("H", "H", 10600),
}


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("-a", "--adapter", type=int, default=0)
    ap.add_argument("--start", type=float, default=950.0, help="IF start MHz")
    ap.add_argument("--stop", type=float, default=2150.0, help="IF stop MHz")
    ap.add_argument("--step", type=float, default=6.0, help="AGC survey step MHz")
    ap.add_argument("--srs", default="45000,27500,15000,8000,4000,2000")
    ap.add_argument("--quadrants", default="VL,HL,VH,HH")
    ap.add_argument("--out", default="/tmp/dvbs-blindscan")
    ap.add_argument("--agc-only", action="store_true")
    ap.add_argument("--min-dip", type=int, default=6000,
                    help="AGC deviation from median considered a carrier")
    return ap.parse_args()


def tune(freq_khz, sr_ksps, pol, band, wait_ms, adapter=0):
    r = subprocess.run([TUNE, "-a", str(adapter), "-f", str(int(freq_khz)),
                        "-s", str(int(sr_ksps)), "-p", pol, "-b", band,
                        "-w", str(wait_ms)],
                       capture_output=True, text=True)
    kv = {}
    for tok in r.stdout.split():
        if "=" in tok:
            k, v = tok.split("=", 1)
            kv[k] = v
    return kv


def main():
    args = parse_args()
    srs = [int(x) for x in args.srs.split(",") if x.strip()]
    quads = [q.strip().upper() for q in args.quadrants.split(",") if q.strip()]
    csv_path = args.out + ".csv"
    conf_path = args.out + ".conf"

    f = args.start
    freqs = []
    while f <= args.stop + 1e-6:
        freqs.append(int(round(f * 1000)))
        f += args.step

    csv = open(csv_path, "w")
    csv.write("quadrant,if_khz,agc,sr_try,lock,cnr,measured_sr\n")
    conf = open(conf_path, "w")

    t_start = time.time()
    found = []
    print(f"# AGC survey {args.start}-{args.stop} MHz step {args.step} "
          f"({len(freqs)} points) x {quads}", flush=True)

    for q in quads:
        pol, band, lo = QUADRANTS[q]
        agc = []
        for i, fk in enumerate(freqs):
            kv = tune(fk, srs[0], pol, band, 40, args.adapter)
            try:
                s = int(kv.get("str", "0"))
            except ValueError:
                s = 0
            agc.append(s)
            csv.write(f"{q},{fk},{s},,0,,\n")
            if (i + 1) % 25 == 0:
                print(f"# {q} AGC {i+1}/{len(freqs)}", flush=True)
        csv.flush()

        vals = sorted(agc)
        med = vals[len(vals) // 2]
        features = []
        for i, s in enumerate(agc):
            if i == 0 or i == len(agc) - 1:
                continue
            if abs(s - med) < args.min_dip:
                continue
            if (s < agc[i - 1] and s < agc[i + 1]) or \
               (s > agc[i - 1] and s > agc[i + 1]):
                features.append(freqs[i])
        # merge features that are within one step
        merged = []
        for fk in features:
            if merged and fk - merged[-1] <= args.step * 1000:
                continue
            merged.append(fk)
        print(f"# {q}: median AGC {med}, {len(merged)} carrier candidates",
              flush=True)

        if args.agc_only:
            continue

        for fk in merged:
            best = None
            for sr in srs:
                for offset in (0, -args.step * 500, args.step * 500):
                    ff = fk + int(offset)
                    kv = tune(ff, sr, pol, band, 2000, args.adapter)
                    lock = kv.get("lock") == "1"
                    msr = int(kv.get("msr", "-1") or -1)
                    cnr = int(kv.get("cnr", "-1") or -1)
                    csv.write(f"{q},{ff},,{sr},{int(lock)},{cnr},{msr}\n")
                    csv.flush()
                    if lock:
                        best = (ff, msr if msr > 0 else sr, cnr)
                        break
                if best:
                    break
            if best:
                ff, msr, cnr = best
                # refine: fine frequency sweep at the measured symbol rate
                step_khz = max(500, int(args.step * 500))
                best_ref = None
                for off in range(-4, 5):
                    f2 = ff + off * step_khz
                    kv = tune(f2, msr, pol, band, 2000, args.adapter)
                    if kv.get("lock") != "1":
                        continue
                    c2 = int(kv.get("cnr", "-1") or -1)
                    m2 = int(kv.get("msr", "-1") or -1)
                    if best_ref is None or c2 > best_ref[2]:
                        best_ref = (f2, m2 if m2 > 0 else msr, c2)
                    csv.write(f"{q},{f2},,{msr},1,{c2},{m2}\n")
                if best_ref:
                    ff, msr, cnr = best_ref
                sat = (ff / 1000.0) + lo
                name = f"{q}_{int(sat)}_{'H' if pol == 'H' else 'V'}_{msr}"
                print(f"HIT {q} IF={ff/1000:.1f} MHz -> {sat:.0f} MHz {pol} "
                      f"SR={msr} CNR={cnr/100:.1f} dB", flush=True)
                conf.write(f"[{name}]\n\tDELIVERY_SYSTEM = DVBS2\n"
                           f"\tFREQUENCY = {int(sat*1000)}\n"
                           f"\tPOLARIZATION = {'HORIZONTAL' if pol=='H' else 'VERTICAL'}\n"
                           f"\tSYMBOL_RATE = {msr*1000}\n\tMODULATION = PSK/8\n"
                           f"\tINNER_FEC = AUTO\n\tINVERSION = AUTO\n\n")
                conf.flush()
                found.append((q, sat, pol, msr, cnr))

    csv.close()
    conf.close()
    print(f"# done in {(time.time()-t_start)/60:.1f} min: {len(found)} transponders")
    print(f"# csv: {csv_path}  conf: {conf_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
